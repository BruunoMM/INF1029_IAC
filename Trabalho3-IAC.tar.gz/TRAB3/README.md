## HOW TO COMPILE
$ make build

## HOW TO RUN
$ make run

## INSTRUCTIONS
Adicionamos um Makefile, para agilizar a compilação e execução do programa.
Você pode configurar os parâmetros de entrada do programa através do mesmo, caso queira.

## MEMBERS
Bruno Miranda Marinho
Guilherme de Alencastro Pasqualette